# Copyright 2017 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import sys

from google.api_core.gapic_v1 import client_info
from google.api_core.gapic_v1 import config
from google.api_core.gapic_v1 import method
from google.api_core.gapic_v1 import routing_header

__all__ = ["client_info", "config", "method", "routing_header"]

if sys.version_info >= (3, 6):
    from google.api_core.gapic_v1 import config_async  # noqa: F401
    from google.api_core.gapic_v1 import method_async  # noqa: F401
    __all__.append("config_async")
    __all__.append("method_async")
