Home-page: https://github.com/chrisjbillington/inotify_simple
Author: Chris Billington
Author-email: chrisjbillington@gmail.com
License: BSD
Description: UNKNOWN
Platform: UNKNOWN
